from blender_asset_tracer import cli

cli.cli_main()
